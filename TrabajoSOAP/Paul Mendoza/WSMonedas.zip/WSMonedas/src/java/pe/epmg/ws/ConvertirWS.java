
package pe.epmg.ws;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;


@WebService(serviceName = "ConvertirWS")
public class ConvertirWS {

    /**
     * Web service operation
     */
    @WebMethod(operationName = "sol_dolar")
    public double sol_dolar(@WebParam(name = "monto") double monto) {
        //asumiendo que 1 Dolar cuesta 3.50 Soles
        
        return (monto/3.50);
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "dolar_sol")
    public double dolar_sol(@WebParam(name = "monto") double monto) {
        //asumiendo que 1 Dolar cuesta 3.50 Soles
        return (monto*3.50);
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "sol_euro")
    public double sol_euro(@WebParam(name = "monto") double monto) {
        //asumiendo que 1 Euro cuesta 3.77 Soles
        return (monto/3.77);
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "euro_sol")
    public double euro_sol(@WebParam(name = "monto") double monto) {
        //asumiendo que 1 Euro cuesta 3.77 Soles
        return (monto*3.77);
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "dolar_euro")
    public double dolar_euro(@WebParam(name = "monto") double monto) {
        //asumiendo que 1 Euro cuesta 1.14 Dolares
        return (monto/1.14);
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "euro_dolar")
    public double euro_dolar(@WebParam(name = "monto") double monto) {
        //asumiendo que 1 Euro cuesta 1.14 Dolares
        return (monto*1.14);
    }
    
    
    
}
